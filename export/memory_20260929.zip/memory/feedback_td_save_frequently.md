---
name: feedback-td-save-frequently
description: "Always save the TouchDesigner project (project.save()) after every verified-working change, not just at the end of a session"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 6e6196d1-8050-46cb-8ac0-e55f42e13106
  modified: 2026-08-16T08:45:23.859Z
---

Call `project.save()` in TouchDesigner right after confirming a change works (no errors, correct live values/visual) — don't batch saves for later, and don't wait until the user asks.

**Why:** During a long TD build session, an unsaved stretch of work (a full architectural redesign — deleting old modules and building ~7 new ones) was lost when TD became unresponsive and had to be restarted, reverting to the last save from well before the redesign. The user was understandably upset ("TD被你弄閃退沒存到檔"). Everything had to be rebuilt from scratch. Two consecutive timeouts on TD API calls (`get_td_info` or similar) turned out to be a reliable warning sign that TD was about to hang/crash — when that pattern appears, stop and tell the user immediately rather than continuing to issue commands blindly.

**How to apply:** In any TD session using the MCP tools: save after each meaningful milestone (a new node chain verified with `get_top_image`/live channel values and zero errors), especially before starting the next risky or exploratory step. If two TD API calls in a row time out, stop, tell the user TD may have crashed, and ask them to check/restart before continuing. After any reconnect, re-verify actual current node state before trusting prior assumptions — TD may have silently reverted to an earlier save.

**Refinement (2026-09-16):** saving mid-turn is not enough — make the LAST action of any turn that touched TD another `project.save()`. Anything done after a save re-dirties the file, including things that feel like read-only diagnostics: `op.store()`/`unstore()` for a timing probe, `clearScriptErrors()`, opening/closing a window COMP. On 2026-09-16 the user had to hit save themselves ("你要記的改完都要存檔，這次幫你存好了") because an fps probe's storage write landed after my `project.save()`. Confirm with `ls -lt <project dir>/*.toe` which version is actually on disk rather than trusting the last save call.
