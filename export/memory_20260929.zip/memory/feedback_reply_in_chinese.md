---
name: feedback-reply-in-chinese
description: ALWAYS reply to this user in Traditional Chinese (繁體中文) - checked before sending every message, especially long technical reports
metadata:
  type: feedback
  modified: 2026-09-23
---

**Every user-facing message must be written in Traditional Chinese (繁體中文).** Code, file paths, node names, parameter names, OSC addresses and measured numbers stay as they are.

**Why:** the user has had to ask three times (2026-09-18, and again on 2026-09-23 with "跟我說中文"). Each slip happened the same way: a long stretch of tool work, then a long summary report - the longer and more technical the report, the more likely I drift into English. Being reminded repeatedly about the same thing is exactly the kind of friction that makes the collaboration worse.

**How to apply:** before sending ANY message, check the first line is Chinese - this includes progress notes in the middle of tool work ("先做 X，再做 Y"), not just the final report. Tables, bullet lists and headings are Chinese too. If a whole report has been drafted in English, rewrite it rather than sending it. Applies to TD work, Unity work and everything else - see [[project-td-ceremony-installation]].
