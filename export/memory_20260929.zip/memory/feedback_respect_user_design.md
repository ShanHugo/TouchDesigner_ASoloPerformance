---
name: feedback-respect-user-design
description: "On the TD ceremony piece, fix only what was asked - the look (colours, brightness, background wash) is the user's design and must not be 'improved' along the way"
metadata:
  node_type: memory
  type: feedback
  modified: 2026-09-16T08:30:00.000Z
---

When the user asks for a technical improvement on [[project-td-ceremony-installation]], change only the thing they asked about. Their words on 2026-09-16: "線清晰不代表要把我之前的設計改掉喔，功能跟顏色都別動" (a sharper line does not mean changing my design - leave function and colour alone).

**Why:** asked to sharpen the blurry body outline, I also switched `silhouette_memory/tinted1` from `add` to `multiply` and doubled `opacityMod1.brightness2`. Numerically that was a big win (the full-canvas wash dropped from 100% of pixels to 3%, line peak 0.305 -> 0.95), but the wash IS the deep-blue background of Act 1 - a deliberate look, not the bug the memory notes describe. The measurable "fix" destroyed an artistic decision. The user was right; both were reverted and verified identical to the original (`memoryOut1` mean 0.1197 vs 0.1196, max 0.1255, bg RGB 0.0196/0.0706/0.1176).

**How to apply:** separate levers into "affects the look" (colours, operands that change how a layer reads, brightness/opacity, composition) and "affects only the technical quality of what they asked for" (resolution, filter type, line width). Apply the second freely; for the first, describe the option with numbers and let the user decide - even when the measurement clearly favours it. If a design choice imposes a hard ceiling (here: `add`-compositing an opaque full-canvas colour clamps line and background to the same value, contrast ceiling 1.07x), say so plainly and offer a variant that keeps the look bit-identical rather than silently taking the better-measuring path. Same rule as [[feedback-unity-branch-workflow]]: someone else's decision is not mine to overwrite.

**Precedence update (2026-09-22):** the user said "老師的權利比我大，所以如果有跟我有些出入，那以老師的為主" - where the teacher's visual direction doc (TD視覺風格設定.docx, see [[project-td-ceremony-installation]]) conflicts with the user's own earlier design choices (e.g. the deep-blue Act 1 wash, subtitle glow, Act 3 kintsugi-on-chest), the teacher's doc wins. Still implement step by step, keep the old version switchable for rollback, and tell the user explicitly which of their earlier choices a step overrides - the rule above still applies to anything the doc does not cover.
