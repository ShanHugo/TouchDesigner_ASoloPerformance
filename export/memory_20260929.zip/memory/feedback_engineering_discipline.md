---
name: feedback-engineering-discipline
description: "User expects peer-engineer discipline on the TD ceremony project - verify no regressions on every change, treat lag/perf complaints as a signal to look for bad code, not just tune parameters"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: e47db669-de3b-4ab0-adc2-e14604d170dc
  modified: 2026-09-09T06:22:22.597Z
---

On the [[project_td_ceremony_installation]] project, the user framed the working relationship explicitly: "我們現在是2個工程師合作完成專案" (we are two engineers collaborating on this project). Standing expectations that follow from that framing:

- **Every add/remove of functionality must be checked against everything else that depends on it**, not just the piece being changed. Concretely on this project: before/after numeric diffs of every custom parameter when touching a script's `onSetupParameters` (since `setuppars.pulse()` silently resets untouched pars to their coded defaults - this has caused real regressions multiple times: `Idleperiod`, `Minperiod`, `Spikewidth`, `Spikeampmax`, `Positionsmoothing` all got silently reverted at various points because a later edit called `setuppars.pulse()` without re-syncing the coded default to the live-tuned value).
- **When the user reports lag/stutter, the default hypothesis should be "some node's code is doing something wasteful," not just "the machine is slow."** Real examples found this way: a disconnected-but-still-`CookLevel.ALWAYS` script CHOP (`crackGen1`) burning cycles forever after being replaced; a `cv2.connectedComponentsWithStats` call running at full 1280x720 resolution every frame when an 8x-downscaled version was ~17x faster with no visible quality loss. Treat a perf complaint as a code-review trigger, not just a "turn some setting down" request.
- **After any non-trivial edit, run the project's own error check (`get_td_node_errors`) and a live value/behavior check before declaring it done** - don't just assert the fix is correct from code review alone. This project's history includes several edits that looked correct on read-through but broke on deploy (e.g. a missing `#` turning a comment continuation line into a syntax error that broke a node shared by two acts).
- **Dead/orphaned code should be found and removed, not just left disconnected "because TD won't cook it."** The user explicitly pushed back on this reasoning once already - CookLevel.ALWAYS script ops are the exception that makes "disconnected = harmless" false, and the user wants unused code actually cleaned up, not just tolerated.

**Why this matters:** this is a long-running, iterative session (many small feature/tuning requests in sequence) where the same handful of script files keep getting re-edited. Without deliberate regression-checking, edits silently undo earlier fixes (has happened repeatedly) or introduce new performance regressions the user has to notice and report back, which erodes trust in the "did you actually check" sense the user is now asking for explicitly.

**How to apply:** before finishing any turn that edits code, ask: (1) did anything else read/depend on what I just changed, and did I verify it still gets what it expects (numeric diff, not just eyeballing), (2) does this change add any per-frame cost, and is it right-sized for what it needs to do, (3) did I actually run the error check + a live read after deploying, not just after writing the code.

**Verification tooling must itself be verified (2026-09-16).** Three scans in one session returned clean results that were meaningless: `root.findChildren(type=windowCOMP)` and `op('/project1').findChildren(depth=12)` both return an empty list inside the TD MCP exec namespace, so every "0 errors project-wide" built on them was a vacuous loop over nothing — and they hid a real script error the user could see as a red badge in the network editor. Before reporting "I checked X and it is clean", confirm the scan actually visited something (print the count of nodes walked, not just the count of hits), and prefer a hand-rolled `.children` recursion here. Same class of mistake as measuring with the wrong clock — see [[feedback-touchdesigner-technical-notes]].
