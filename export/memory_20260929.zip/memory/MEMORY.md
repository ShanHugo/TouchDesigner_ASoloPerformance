# Memory Index

- [TD Ceremony Installation Project](project_td_ceremony_installation.md) — 3-act caregiver TouchDesigner piece (vows / feeding / card + embrace + kintsugi), architecture, Unity OSC facts, open decisions
- [Save TD Frequently](feedback_td_save_frequently.md) — call project.save() after every verified change; watch for 2x-timeout crash warning sign
- [TouchDesigner Technical Notes](feedback_td_technical_notes.md) — mirrorTOP/feedbackTOP/enum gotchas, MediaPipe-in-TD patterns, scene-gate every act state machine (cross-act gesture leaks)
- [Engineering Discipline Expected](feedback_engineering_discipline.md) — treat as peer engineer: verify no regressions on every change (numeric par diffs), treat lag reports as a code-quality signal, clean up dead code, always error-check + live-check after deploying
- [Unity Changes Go On A Branch](feedback_unity_branch_workflow.md) — partner owns the repo; branch for any Unity edit, NEVER push main, normally no push at all; missing-asset + local URP workaround notes
- [Respect The User's Design](feedback_respect_user_design.md) — fix only what was asked; look is a design decision; BUT the teacher's visual doc overrides the user's earlier choices where they conflict
- [Reply In Chinese](feedback_reply_in_chinese.md) — ALWAYS 繁體中文, check before every message (slipped 3 times on long reports)
